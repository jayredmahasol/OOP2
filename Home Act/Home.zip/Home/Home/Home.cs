﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Home
{
    internal class Home
    {
        double priceOfHome, interestRate, downPayment;
        double downPaymentTotal, amountFinanced, rate, monthlyPayment, totalInterest;
        public static void Main(string[] args)
        {
            Home home = new Home();
            home.Display();
        }

        public void InputValues()
        {
            Console.Write("Price of Home \t\t>> ");
            priceOfHome = Convert.ToDouble(Console.ReadLine());
            Console.Write("Interest Rate \t\t>> ");
            interestRate = Convert.ToDouble(Console.ReadLine());
            Console.Write("Percent as Down Payment >> ");
            downPayment = Convert.ToDouble(Console.ReadLine());
        }

        public double DownPayment(double priceOfHome, double downPayment)
        {
            downPaymentTotal = (priceOfHome * (downPayment / 100));
            return downPaymentTotal;
        }

        public double FinancedAmount(double priceOfHome, double downPaymentTotal)
        {
            amountFinanced = (priceOfHome - downPaymentTotal);
            return amountFinanced;
        }

        public double MonthlyPayment(double interestRate, double priceOfHome, double downPayment)
        {
            rate = ((interestRate / 100) / 12);
            double solve1 = (Math.Pow(1 + rate, 360) - 1);
            double solve2 = rate / solve1;
            double solve3 = solve2 + rate; 
            monthlyPayment = solve3 * FinancedAmount(priceOfHome, DownPayment(priceOfHome, downPayment));
            return monthlyPayment;
        }

        public double TotalInterest(double monthlyPayment, double priceOfHome)
        {
            double month = 30 * 12;
            totalInterest = (monthlyPayment * month) - priceOfHome - 0.01; 
            return totalInterest;
        }

        public void Display()
        {
            InputValues();
            Console.WriteLine();
            Console.WriteLine($"Down Payment: \t {DownPayment(priceOfHome, downPayment):C}");
            Console.WriteLine($"Amount Financed: {FinancedAmount(priceOfHome, DownPayment(priceOfHome, downPayment)):C}");
            Console.WriteLine($"Monthly Payment: {MonthlyPayment(interestRate, priceOfHome, downPayment):C}");
            Console.WriteLine($"Total Interest:\t {TotalInterest(monthlyPayment, priceOfHome):C}");

        }


    }
}
