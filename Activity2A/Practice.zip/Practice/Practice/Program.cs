﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practice
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] ar = new int[] { 1, 2, 3, 4, 5 };
            int size = ar.Length;
            int searched;

            Practice2 prac = new Practice2(ar, size);

            Console.Write("\nEnter data: ");
            searched = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(prac.Search(searched));
            Console.WriteLine("The number of data is: " + prac.Count());
            /*
            int size = 5;
            int[] myArr = new int[size];
            int search;

            //Practice2 prac = new Practice2();
            //Practice2 prac = new Practice2(size);


            
            for (int a = 0; a < size; a++)
            {
                myArr[a] = a + 1;
                Practice2 prac = new Practice2(myArr[a], size);
                prac.Print();
            }

            for (int a = 0; a < size; a++)
            {
                myArr[a] = a + 1;
                Console.Write("Enter data to search: ");
                search = Convert.ToInt32(Console.ReadLine());
                Practice2 prac = new Practice2(myArr[a], size);
                Console.WriteLine(prac.Search(search));
            }
            */



            //prac.Print();
        }
    }
}
