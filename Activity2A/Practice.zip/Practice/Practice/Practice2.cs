﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Practice
{
    internal class Practice2
    {
        private int [] myArr;
        private int size;
       
        public Practice2(int [] myArr, int size)
        {
            this.size = size;
            this.myArr = myArr;
            for (int i = 0; i < this.size; i++)
            {
                Console.Write(myArr[i] + " ");
            }
        }

        public string Search(int searched)
        {
            for (int i = 0; i < size; i++)
            {
                if (searched == this.myArr[i])
                    return "Found"; 
            }
            return "Not Found";
        }
        public int Count()
        {
            return size;
        }


        /*
        public void Print()
        {
            Console.Write(this.myArr + " ");
        }

        public int Search(int search)
        {
            for (int i = 0; i < this.size; i++)
            {
                if (search == this.myArr)
                {
                    return this.myArr;
                }
            }
            return -1;

        }

        
        */
    }
}
